

<?php $__env->startSection('content'); ?>
<div class="content-header">
    <div class="container-fluid">
        <div class="d-flex justify-content-between mb-3 flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h2 class="d-inline-flex align-items-center mb-0">
                Members
            </h4>

            <div class="btn-group align-items-center btn-group-job-acion">
                <a href="<?php echo e(route('members.index')); ?>" class="btn btn-outline-secondary px-3">Bask to Members</a>
            </div>
        </div>
    </div>
</div>

<div class="content">
    <div class="container-fluid">
        <div class="card mb-0">
            <?php echo e(html()->form('POST')
                    ->route('members.store')
                    ->open()); ?>

                <div class="card-body">
                    <table class="table table-striped-columns">
                        <tr>
                            <th class="text-end">First Name: </th>
                            <td><?php echo e(html()->input('firstname')->class('form-control')); ?></td>

                            <th class="text-end">DS Division: <span class="text-danger">*</span></th>
                            <td><?php echo e(html()->select('ds_division_id')
                                        ->options($dsDivisions)
                                        ->placeholder('')
                                        ->required(true)
                                        ->class('form-control')); ?></td>
                        </tr>

                        <tr>
                            <th class="text-end">Last Name: <span class="text-danger">*</span></th>
                            <td><?php echo e(html()->input('lastname')
                                        ->class('form-control')
                                        ->required(true)); ?></td>

                            <th class="text-end">Date of Birth: </th>
                            <td><?php echo e(html()->date('dob')
                                        ->attribute('max', date('Y-m-d', strtotime('-18 years')))
                                        ->class('form-control')); ?></td>
                        </tr>

                        <tr>
                            <th class="text-end">Email: </th>
                            <td><?php echo e(html()->email('email')->class('form-control')); ?></td>

                            <th class="text-end">Summery: </th>
                            <td><?php echo e(html()->textarea('summery')
                                        ->rows(5)
                                        ->class('form-control')); ?></td>
                        </tr>
                    </table>
                </div>
                <div class="card-footer">
                    <div class="text-end">
                        <button type="reset" class="btn btn-secondary px-3">Reset</button>
                        <button type="submit" class="btn btn-primary px-3">Save</button>
                    </div>
                </div>
            <?php echo e(html()->form()->close()); ?>

        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('page_scripts'); ?>
<script>

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Www\accura-test\resources\views/users/create.blade.php ENDPATH**/ ?>