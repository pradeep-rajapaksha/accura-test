
<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse vh-100">
    <div class="position-sticky pt-3">
        <ul class="nav nav-pills nav-fill flex-column align-items-start">
            <li class="nav-item c-nav-item">
                <a class="nav-link <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>" aria-current="page" href="<?php echo e(route('dashboard')); ?>">
                    Dashboard
                </a>
            </li>
            <li class="nav-item c-nav-item">
                <a class="nav-link <?php echo e(request()->routeIs('members.*') ? 'active' : ''); ?>" href="<?php echo e(route('members.index')); ?>">
                    Members
                </a>
            </li>
            <li class="nav-item c-nav-item">
                <a class="nav-link <?php echo e(request()->routeIs('ds-divisions.*') ? 'active' : ''); ?>" href="<?php echo e(route('ds-divisions.index')); ?>">
                    DS Divisions
                </a>
            </li>
        </ul>
        
        
        <hr>
        <ul class="nav flex-column mb-2">
            
            <li class="nav-item">
                <?php echo e(html()->form('POST')->route('auth.logout')
                    ->class('d-inline')
                    ->open()); ?>


                    <button type="submit" class="nav-link">Logout</button>
                <?php echo e(html()->form()->close()); ?>

            </li>
        </ul>
    </div>
</nav><?php /**PATH C:\Users\user\Www\accura-test\resources\views/layouts/side-menu.blade.php ENDPATH**/ ?>