

<?php $__env->startSection('content'); ?>
<div class="content-header">
    <div class="container-fluid">
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h2 class="d-inline-flex align-items-center mb-0">
                Members
            </h4>

            <div class="btn-group align-items-center btn-group-job-acion">
                <a href="<?php echo e(route('members.create')); ?>" class="btn btn-outline-primary px-3">Create a New Member</a>
            </div>
        </div>
    </div>
</div>

<div class="content">
    <div class="container-fluid">
        <div class="card mb-0">
            <div class="card-body">
                <div class="d-flex justify-content-end flex-wrap flex-md-nowrap align-items-center py-1 mb-3 border-bottom">
                    <?php echo e(html()->form('GET', '')->open()); ?>

                        <div class="input-group mb-3">
                            <input type="text" name="search" class="form-control" placeholder="Search by Last Name" value="<?php echo e(request()->get('search')); ?>"/>
                            <button class="btn btn-outline-secondary" type="submit" id="button-addon2">Search</button>
                        </div>
                    <?php echo e(html()->form()->close()); ?>

                </div>
                <table id="table-branches" class="table table-striped">
                    <thead>
                        <tr>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Date of Birth</th>
                            <th>DS Division</th>
                            <th>Created At</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($member->firstname); ?></td>
                                <td>
                                    <a href="<?php echo e(route('members.show', $member->id)); ?>"><?php echo e($member->lastname); ?></a>
                                </td>
                                <td><?php echo e(date('Y-m-d', strtotime($member->dob))); ?></td>
                                <td><?php echo e($member->dsDivision?->name ?? ''); ?></td>
                                <td><?php echo e($member->created_at); ?></td>
                                <td class="text-center">
                                    <a href="<?php echo e(route('members.edit', $member->id)); ?>" class="btn btn-sm btn-link text-primary py-0">Edit</a>

                                    <?php echo e(html()->form('DELETE')->route('members.destroy', $member->id)
                                        ->class('d-inline')
                                        ->attribute('onsubmit', 'return confirm("Are you sure you want to delete this member?");')
                                        ->open()); ?>


                                        <button type="submit" class="btn btn-sm btn-link text-danger py-0">Delete</button>
                                    <?php echo e(html()->form()->close()); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6">No members available</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <?php echo e($members->withQueryString()->links()); ?>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Www\accura-test\resources\views/members/index.blade.php ENDPATH**/ ?>