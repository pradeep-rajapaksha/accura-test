import './bootstrap';

// import * as Popper from '@popperjs/core';
// window.Popper = Popper;
// import 'bootstrap';

// import * as feather from 'feather-icons';

// feather.replace();